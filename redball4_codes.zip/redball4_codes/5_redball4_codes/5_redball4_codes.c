﻿#include "raylib.h"
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

// Constants
#define SCREEN_WIDTH 1600
#define SCREEN_HEIGHT 720
#define GRAVITY 0.5f
#define JUMP_FORCE -10.0f
#define PLAYER_RADIUS 20
#define PLATFORM_COUNT 8
#define ROCK_COUNT 2
#define BOT_COUNT 4
#define COIN_RADIUS 7
#define MAX_LIVES 3
#define LEFT_BOUNDARY_OFFSET 200
#define RIGHT_BOUNDARY_OFFSET 200
#define GAP_COUNT 2
#define GAP_WIDTH 120
#define MAX_NAME_LENGTH 15
#define MAX_PLAYERS 500

// Struct definitions
typedef struct PlayerRecord {
    char name[16];
    float bestScore;
    bool exists;
} PlayerRecord;

typedef struct Player {
    Vector2 position;
    Vector2 velocity;
    bool onGround;
    int lives;
    int coins;
    bool isDead;
    bool gameCompleted;
    float invulnerabilityTimer;
    float startX;
    float rotation;
    float deathEffectTimer;
    float deathRotation;
    bool isDeathAnimating;
    bool isInWater;
    bool isOnFloatingBox;
} Player;

typedef struct Platform {
    Rectangle rect;
    bool hasCoin;
    bool coinCollected;
    bool isFinishLine;
} Platform;

typedef struct Rock {
    Rectangle rect;
} Rock;

typedef struct Bot {
    Rectangle rect;
    bool alive;
    int direction;
    float speed;
    float leftBound;
    float rightBound;
    float stuckTimer;
    Vector2 lastPosition;
    float rotation; // Yeni: Botun dönüş açısı
} Bot;

typedef struct Gap {
    float startX;
    float endX;
    bool active;
} Gap;

typedef struct Coin {
    Vector2 position;
    bool collected;
} Coin;

typedef struct FloatingBox {
    Rectangle rect;
    float originalY;
    float waveOffset;
    Vector2 velocity; // Platformun hareket hızı
} FloatingBox;

typedef struct VanishingPlatform {
    Rectangle rect;
    bool isVisible;
    float visibilityTimer;
    float visibilityCycle; // Görünür/görünmez döngü süresi
    bool hasCoin;
    bool coinCollected;
} VanishingPlatform;

typedef struct PushableBox {
    Rectangle rect;
    Vector2 velocity;
    float originalX;
    float rightBound; // Kutu için sağ sınır
} PushableBox;

typedef struct WaterArea {
    Rectangle rect;
    float waveTime;
    float waveHeight;
} WaterArea;

typedef enum GameState {
    STATE_MENU,
    STATE_SETTINGS,
    STATE_ENTER_NAME,
    STATE_LEVEL_SELECT,
    STATE_PLAYING,
    STATE_LEVEL_TRANSITION,
    STATE_GAME_OVER,
    STATE_LEADERBOARD
} GameState;

// Function prototypes
void DrawLevelIntro(void);
void DrawFinishFlag(float x, float y);
void InitializeWaterAndBoxes(void);
void UpdateWaterAndBoxes(float deltaTime);
void DrawWaterAndBoxes(void);
void InitializeGame(void);
void UpdateGame(void);
void DrawGame(void);
void InitializeMenuButtons(void);
void InitializeMenuAssets(void);
void UnloadMenuAssets(void);
void DrawMenu(void);
void HandleMenuInput(void);
void DrawSettings(void);
void HandleSettingsInput(void);
void HandleEnterNameInput(void);
void DrawEnterName(void);
void DrawLeaderboard(void);
void HandleGameInput(void);
void HandleLeaderboardInput(void);
void InitializeLevel(void);
void ResetGame(Player* player);
bool IsValidPlayerName(const char* name);
bool PlayerNameExists(const char* name);
int GetPlayerIndex(const char* name);
void AddNewPlayer(const char* name);
void UpdatePlayerScore(const char* name, float score);
float GetPlayerBestScore(const char* name);
void SaveGameSettings(void);
void LoadGameSettings(void);
bool CheckCollisionCircleRect(Vector2 center, float radius, Rectangle rect);
bool CheckPlayerInGap(Vector2 playerPos, float radius);
bool CheckCollisionCircleCircle(Vector2 center1, float radius1, Vector2 center2, float radius2);
void GenerateGaps(void);
void GeneratePlatforms(void);
void GenerateRocks(void);
void GenerateBots(void);
bool HandleRectangleCollision(Vector2* playerPos, Vector2* playerVel, Vector2 oldPos, float radius, Rectangle rect, bool* onGround, bool isPlatform);

// Global variables
int level1Coins = 0; // 1. seviyede toplanan coinler
static bool showingLevelIntro = false;
static float levelIntroTimer = 0.0f;
static float levelIntroAlpha = 0.0f;
static float titleRotation = 0.0f;
static float flagWaveTime = 0.0f;
static int currentLevel = 1;
static float levelTransitionTimer = 0.0f;
static const float levelTransitionDuration = 3.0f;
static Rectangle menuButtons[4];
static bool menuButtonHover[4];
static Font gameFont;
static Texture2D menuBgTexture;
static Texture2D backgroundTexture;
Texture2D enemyTexture;
Texture2D platformTexture;
Texture2D groundTexture;
Texture2D rockTexture;
Texture2D wallTexture;
Texture2D coinIcon;
Texture2D heartFull;
Texture2D heartEmpty;




Music gameplayMusic;
bool musicOn = true;

Sound coinSound;
Sound botKillSound;
Sound fallSound;
Sound drownSound;
Sound jumpSound;







// Game state variables
Player player = { 0 };
Camera2D camera = { 0 };
Rectangle groundSegments[150];
int segmentCount = 0;
time_t startTime = 0, endTime = 0;
bool timeStopped = false;
time_t level1EndTime = 0; // Seviye 1 tamamlanma zamanı
bool gameInitialized = false;

// Player records and settings
PlayerRecord playerRecords[MAX_PLAYERS] = { 0 };
int totalPlayers = 0;
char currentPlayerName[16] = "";
bool nameSet = false;
bool soundOn = true;
char nameErrorMessage[100] = "";
GameState currentGameState = STATE_MENU;

// Game objects
Platform platforms[PLATFORM_COUNT + 1] = { 0 };
Rock rocks[ROCK_COUNT] = { 0 };
Bot bots[BOT_COUNT] = { 0 };
Gap gaps[GAP_COUNT] = { 0 };
Coin extraCoins[3] = { 0 }; // Added Coin array
WaterArea waterAreas[2] = { 0 };
FloatingBox floatingBoxes[2] = { 0 };
VanishingPlatform vanishingPlatform = { 0 };
PushableBox pushableBox = { 0 };
int maxCoins = 0;

void DrawLevelIntro(void) {
    DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
        Fade(BLACK, levelIntroAlpha * 0.7f));

    const char* levelText = TextFormat("LEVEL %d", currentLevel);
    int fontSize = 80;
    int textWidth = MeasureText(levelText, fontSize);

    DrawText(levelText,
        SCREEN_WIDTH / 2 - textWidth / 2 + 4,
        SCREEN_HEIGHT / 2 - fontSize / 2 + 4,
        fontSize,
        Fade(BLACK, levelIntroAlpha * 0.5f));

    DrawText(levelText,
        SCREEN_WIDTH / 2 - textWidth / 2,
        SCREEN_HEIGHT / 2 - fontSize / 2,
        fontSize,
        Fade(WHITE, levelIntroAlpha));
}

void DrawFinishFlag(float x, float y) {
    float flagHeight = 150;
    float flagWidth = 100;
    float poleWidth = 8;
    float baseY;

    // Seviye geçişi sırasında 1. seviye için baseY kullan
    if (currentGameState == STATE_LEVEL_TRANSITION) {
        baseY = SCREEN_HEIGHT - 40; // 1. seviye için sabit zemin
    }
    else {
        baseY = (currentLevel == 2) ? y + SCREEN_HEIGHT + 14 : SCREEN_HEIGHT - 40; // Normal davranış
    }

    DrawRectangle(x, baseY - flagHeight, poleWidth, flagHeight, DARKGRAY);

    flagWaveTime += GetFrameTime() * 5.0f;

    for (int i = 0; i < flagWidth; i++) {
        float waveOffset = sinf(flagWaveTime + (float)i * 0.05f) * 10;
        float yPos = baseY - flagHeight + 10;

        DrawLineEx(
            (Vector2) {
            x + poleWidth + i, yPos + waveOffset
        },
            (Vector2) {
            x + poleWidth + i, yPos + 60 + waveOffset * 0.5f
        },
            2,
            BLACK
        );
    }

    const char* finishText = "FINISH";
    int fontSize = 20;
    float textX = x + poleWidth + 10;
    float textY = baseY - flagHeight + 29;
    float textWaveOffset = sinf(flagWaveTime) * 5;

    DrawText(finishText, textX, textY + textWaveOffset, fontSize, WHITE);
}
void InitializeWaterAndBoxes(void) {
    if (currentLevel == 1) {
        waterAreas[0].rect = (Rectangle){ 0, 0, 0, 0 };
        waterAreas[0].waveTime = 0;
        waterAreas[0].waveHeight = 0;
        waterAreas[1].rect = (Rectangle){ 0, 0, 0, 0 };
        waterAreas[1].waveTime = 0;
        waterAreas[1].waveHeight = 0;
        floatingBoxes[0].rect = (Rectangle){ 0, 0, 0, 0 };
        floatingBoxes[1].rect = (Rectangle){ 0, 0, 0, 0 };
        vanishingPlatform.rect = (Rectangle){ 0, 0, 0, 0 };
        vanishingPlatform.isVisible = false;
        vanishingPlatform.visibilityTimer = 0.0f;
        vanishingPlatform.visibilityCycle = 0.0f;
        vanishingPlatform.hasCoin = false;
        vanishingPlatform.coinCollected = false;
    }
    else {
        waterAreas[0].rect = (Rectangle){ 400, SCREEN_HEIGHT - 40, 350, 60 }; // Yükseklik 60, zeminin üstünde
        waterAreas[0].waveTime = 0;
        waterAreas[0].waveHeight = 15; // Dalga yüksekliği artırıldı
        waterAreas[1].rect = (Rectangle){ 0, 0, 0, 0 };
        waterAreas[1].waveTime = 0;
        waterAreas[1].waveHeight = 0;

        floatingBoxes[0].rect = (Rectangle){ 1220, SCREEN_HEIGHT - 100, 100, 20 };
        floatingBoxes[0].originalY = floatingBoxes[0].rect.y;
        floatingBoxes[0].waveOffset = 0.0f;
        floatingBoxes[1].rect = (Rectangle){ 0, 0, 0, 0 };

        vanishingPlatform.rect = (Rectangle){ 525, SCREEN_HEIGHT - 100, 100, 20 };
        vanishingPlatform.isVisible = true;
        vanishingPlatform.visibilityTimer = 0.0f;
        vanishingPlatform.visibilityCycle = 2.0f; // 2 saniye görünür, 2 saniye görünmez
        vanishingPlatform.hasCoin = true;
        vanishingPlatform.coinCollected = false;
    }
}

void UpdateWaterAndBoxes(float deltaTime) {
    if (currentLevel == 1) return;

    // Su dalgası güncelleme
    waterAreas[0].waveTime += deltaTime;
    float waveOffset = sinf(waterAreas[0].waveTime * 2) * waterAreas[0].waveHeight;

    // Görünür/görünmez platform güncelleme
    vanishingPlatform.visibilityTimer += deltaTime;
    if (vanishingPlatform.visibilityTimer >= vanishingPlatform.visibilityCycle) {
        vanishingPlatform.isVisible = !vanishingPlatform.isVisible;
        vanishingPlatform.visibilityTimer = 0.0f;
    }

    // Hareket eden platform güncelleme ve hız hesaplama
    float oldBoxX = floatingBoxes[0].rect.x;
    float oldBoxY = floatingBoxes[0].rect.y;
    floatingBoxes[0].rect.x = 1220 + sinf(waterAreas[0].waveTime * 1.5f) * 100; // Boşlukta ileri-geri hareket
    floatingBoxes[0].rect.y = floatingBoxes[0].originalY + waveOffset;
    floatingBoxes[0].velocity.x = floatingBoxes[0].rect.x - oldBoxX; // Yatay hareket miktarı
    floatingBoxes[0].velocity.y = floatingBoxes[0].rect.y - oldBoxY; // Dikey hareket miktarı

    // Su ile çarpışma
    if (CheckCollisionCircleRect(player.position, PLAYER_RADIUS, waterAreas[0].rect)) {
        if (!player.isDead) {
            if (soundOn) PlaySound(drownSound); {

            }
            player.lives = 0; // Canları sıfırla
            player.isDead = true; // Oyuncuyu ölü olarak işaretle
            player.isDeathAnimating = true; // Ölüm animasyonunu başlat
            player.deathEffectTimer = 0.0f;
            player.deathRotation = 0.0f;
            player.velocity.y = JUMP_FORCE / 2; // Yukarı sıçrama
        }
    }

    // Görünür platform ile çarpışma
    if (vanishingPlatform.isVisible && CheckCollisionCircleRect(player.position, PLAYER_RADIUS, vanishingPlatform.rect)) {
        player.onGround = true;
        player.position.y = vanishingPlatform.rect.y - PLAYER_RADIUS;
        player.velocity.y = 0;
    }

    // Hareket eden platform ile çarpışma
    if (CheckCollisionCircleRect(player.position, PLAYER_RADIUS, floatingBoxes[0].rect)) {
        player.isOnFloatingBox = true;
        player.onGround = true;
        player.position.y = floatingBoxes[0].rect.y - PLAYER_RADIUS;
        player.velocity.y = 0;
        // Top platformla birlikte hareket etsin
        player.position.x += floatingBoxes[0].velocity.x;
        player.position.y += floatingBoxes[0].velocity.y;
    }
    else {
        player.isOnFloatingBox = false;
    }
}

void DrawWaterAndBoxes(void) {
    if (currentLevel == 1) return;

    // Su çizimi
    Color waterBaseColor = (Color){ 30, 144, 255, 200 }; // Daha canlı mavi
    Color waterShadowColor = (Color){ 0, 100, 200, 100 }; // Gölge katmanı
    DrawRectangleGradientV(waterAreas[0].rect.x, waterAreas[0].rect.y,
        waterAreas[0].rect.width, waterAreas[0].rect.height,
        waterBaseColor, waterShadowColor); // Derinlik efekti

    // Birinci dalga katmanı (ana dalgalar)
    for (int i = 0; i < waterAreas[0].rect.width; i += 10) {
        float waveY = waterAreas[0].rect.y +
            sinf((waterAreas[0].waveTime * 2) + (i * 0.05f)) *
            waterAreas[0].waveHeight;
        DrawLineEx(
            (Vector2) {
            waterAreas[0].rect.x + i, waveY
        },
            (Vector2) {
            waterAreas[0].rect.x + i + 10, waveY
        },
            3,
            (Color) {
            135, 206, 250, 220
        } // Açık mavi, hafif şeffaf
        );
    }

    // İkinci dalga katmanı (detay dalgalar)
    for (int i = 0; i < waterAreas[0].rect.width; i += 15) {
        float waveY = waterAreas[0].rect.y + 5 +
            sinf((waterAreas[0].waveTime * 3) + (i * 0.03f)) *
            (waterAreas[0].waveHeight * 0.5f);
        DrawLineEx(
            (Vector2) {
            waterAreas[0].rect.x + i, waveY
        },
            (Vector2) {
            waterAreas[0].rect.x + i + 15, waveY
        },
            1.5f,
            (Color) {
            255, 255, 255, 150
        } // Beyaz, daha ince dalgalar
        );
    }

    // Görünür platform çizimi
    if (vanishingPlatform.isVisible) {
        DrawRectangleRec(vanishingPlatform.rect, GRAY);
        DrawRectangleLinesEx(vanishingPlatform.rect, 2, DARKGRAY);
        if (vanishingPlatform.hasCoin && !vanishingPlatform.coinCollected) {
            Vector2 coinPos = { vanishingPlatform.rect.x + vanishingPlatform.rect.width / 2, vanishingPlatform.rect.y - 15 };
            DrawCircleV(coinPos, COIN_RADIUS, GOLD);
            DrawCircleLinesV(coinPos, COIN_RADIUS, ORANGE);
        }
    }

    // Hareket eden platform çizimi
    DrawRectangleRec(floatingBoxes[0].rect, GRAY);
    DrawRectangleLinesEx(floatingBoxes[0].rect, 2, DARKGRAY);
}

void InitializeLevel(void) {
    int currentCoins = player.coins; // Mevcut coinleri sakla
    time_t currentStartTime = startTime;

    player.position = (Vector2){ -20, SCREEN_HEIGHT - 300 };
    player.startX = player.position.x;
    player.velocity = (Vector2){ 0, 0 };
    player.onGround = false;
    player.lives = MAX_LIVES;
    player.rotation = 0.0f;
    player.isDead = false;
    player.gameCompleted = false;
    player.invulnerabilityTimer = 0.0f;
    player.deathEffectTimer = 0.0f;
    player.deathRotation = 0.0f;
    player.isDeathAnimating = false;

    player.coins = currentCoins; // Coinleri koru
    if (currentGameState != STATE_LEVEL_TRANSITION) {
        startTime = time(NULL);
    }

    InitializeWaterAndBoxes();
    GenerateGaps();
    GeneratePlatforms();
    GenerateRocks();
    GenerateBots();

    camera.offset = (Vector2){ SCREEN_WIDTH / 2.0f, SCREEN_HEIGHT / 2.0f };
    camera.target = (Vector2){ 0, 0 };
    camera.zoom = 1.0f;

    segmentCount = 0;
    float segmentWidth = 35;
    float startX = -300;
    float endX = 3000;
    for (float currentX = startX; currentX < endX && segmentCount < 150; currentX += segmentWidth) {
        bool inGap = false;
        bool inWater = false;
        for (int i = 0; i < GAP_COUNT; i++) {
            if (gaps[i].active) {
                if (currentX >= gaps[i].startX && currentX + segmentWidth <= gaps[i].endX) {
                    inGap = true;
                    break;
                }
                if ((currentX < gaps[i].endX && currentX + segmentWidth > gaps[i].startX)) {
                    inGap = true;
                    break;
                }
            }
        }
        if (currentLevel == 2) {
            if (currentX < waterAreas[0].rect.x + waterAreas[0].rect.width &&
                currentX + segmentWidth > waterAreas[0].rect.x) {
                inWater = true;
            }
        }
        if (!inGap && !inWater) {
            float groundY = SCREEN_HEIGHT - 40;
            if (currentLevel == 2 && currentX >= 2300) {
                groundY = SCREEN_HEIGHT - 190;
            }
            groundSegments[segmentCount] = (Rectangle){
                currentX,
                groundY,
                segmentWidth,
                40
            };
            segmentCount++;
        }
    }
    // Yeni: 2. seviyede zemin bağlantısı (boşluğu etkilemez)
    if (currentLevel == 2 && segmentCount < 150) {
        groundSegments[segmentCount] = (Rectangle){
            2300, // Tam x = 2300’de
            SCREEN_HEIGHT - 190, // Üst zemin seviyesi
            segmentWidth, // Aynı genişlik
            150
        };
        segmentCount++;
    }
}

void InitializeGame(void) {
    InitAudioDevice();
    if (!IsAudioDeviceReady()) {
        TraceLog(LOG_ERROR, "Ses sistemi başlatılamadı!");
    }
    else {
        TraceLog(LOG_INFO, "Ses sistemi hazır.");
    }
    currentLevel = 1;
    InitializeLevel();
    startTime = time(NULL);
    timeStopped = false;
    gameInitialized = true;
    showingLevelIntro = true;
    levelIntroTimer = 2.0f;
    levelIntroAlpha = 1.0f;
    backgroundTexture = LoadTexture("assets/pictures/background.jpg");
    enemyTexture = LoadTexture("assets/pictures/enemy.png");
    platformTexture = LoadTexture("assets/pictures/platform.png");
    groundTexture = LoadTexture("assets/pictures/ground.jpg");
    rockTexture = LoadTexture("assets/pictures/rock.jpg");
    wallTexture = LoadTexture("assets/pictures/wall.png");
    heartFull = LoadTexture("assets/pictures/heart_full.png");
    heartEmpty = LoadTexture("assets/pictures/heart_empty.png");
    coinIcon = LoadTexture("assets/pictures/coins.png");





    gameplayMusic = LoadMusicStream("assets/sounds/gameplay.mp3");
    if (musicOn) {
        PlayMusicStream(gameplayMusic);
    }
    coinSound = LoadSound("assets/sounds/coins.wav");
    botKillSound = LoadSound("assets/sounds/bots.wav");
    fallSound = LoadSound("assets/sounds/fall.wav");
    drownSound = LoadSound("assets/sounds/drown.wav");
    jumpSound = LoadSound("assets/sounds/bouncing.wav");





}

void UpdateGame(void) {
    float deltaTime = GetFrameTime();
    if (musicOn) {
        UpdateMusicStream(gameplayMusic);
        if (IsKeyPressed(KEY_ONE)) PlaySound(coinSound);
        if (IsKeyPressed(KEY_TWO)) PlaySound(botKillSound);

    }

    // Ölüm animasyonu kontrolü
    if (player.isDeathAnimating) {
        player.deathEffectTimer += deltaTime;
        player.deathRotation += 360.0f * deltaTime; // Top dönerek düşer
        player.position.y += player.velocity.y; // Düşme hareketi devam eder
        player.velocity.y += GRAVITY; // Yerçekimi uygulanır
        if (player.deathEffectTimer >= 1.0f) { // 1 saniyelik animasyon süresi
            player.isDeathAnimating = false;
            player.isDead = true;
            currentGameState = STATE_GAME_OVER; // Animasyon bitti, oyun biter
        }
        // R tuşu kontrolü
        if (IsKeyPressed(KEY_R)) {
            ResetGame(&player);
            if (currentLevel == 2) {
                startTime = time(NULL) - level1EndTime; // Seviye 1'in süresinden devam et
            }
            else {
                startTime = time(NULL); // Seviye 1 için sıfırla
            }
            timeStopped = false;
            showingLevelIntro = true;
            levelIntroTimer = 2.0f;
            levelIntroAlpha = 1.0f;
            currentGameState = STATE_PLAYING;
        }
        // return kaldırılarak diğer kontroller devam eder
    }

    if (showingLevelIntro) {
        levelIntroTimer -= deltaTime;
        levelIntroAlpha = levelIntroTimer / 2.0f;

        if (levelIntroTimer <= 0) {
            showingLevelIntro = false;
        }
        return;
    }

    if (currentGameState == STATE_LEVEL_TRANSITION) {
        timeStopped = true; // Seviye geçişinde zamanı durdur
        levelTransitionTimer -= deltaTime;
        if (levelTransitionTimer <= 0) {
            int currentCoins = player.coins;
            InitializeLevel();
            player.coins = currentCoins;
            if (currentLevel == 2) {
                startTime = time(NULL) - level1EndTime; // Seviye 1'in süresinden devam et

            }
            timeStopped = false; // Yeni seviyede zamanı devam ettir
            currentGameState = STATE_PLAYING;
            showingLevelIntro = true;
            levelIntroTimer = 2.0f;
            levelIntroAlpha = 1.0f;
        }
        return;
    }

    if (player.gameCompleted || player.isDead) {
        if (IsKeyPressed(KEY_R)) {
            if (player.gameCompleted) {
                currentLevel = 1;
            }
            ResetGame(&player);
            startTime = time(NULL);
            timeStopped = false;
            showingLevelIntro = true;
            levelIntroTimer = 2.0f;
            levelIntroAlpha = 1.0f;
        }
        return;
    }

    if (!timeStopped && !player.gameCompleted && currentGameState != STATE_LEVEL_TRANSITION) {
        endTime = time(NULL); // Sadece oyun oynanırken ve geçiş değilken zamanı güncelle
    }

    if (player.invulnerabilityTimer > 0) {
        player.invulnerabilityTimer -= deltaTime;
    }

    // Oyuncu hareket kontrolleri (sadece oyuncu canlıysa)
    if (!player.isDead && !player.isDeathAnimating) {
        if (IsKeyDown(KEY_RIGHT) || IsKeyDown(KEY_D)) player.velocity.x = 5;
        else if (IsKeyDown(KEY_LEFT) || IsKeyDown(KEY_A)) player.velocity.x = -5;
        else player.velocity.x = 0;

        if ((IsKeyPressed(KEY_SPACE) || IsKeyPressed(KEY_UP) || IsKeyPressed(KEY_W)) && player.onGround) {
            player.velocity.y = JUMP_FORCE;
            player.onGround = false;
            if (soundOn) PlaySound(jumpSound);  // Zıplama sesi

        }
    }
    else {
        player.velocity.x = 0; // Ölü veya animasyon sırasında hareketi durdur
    }

    player.velocity.y += GRAVITY;

    if (player.velocity.x != 0) {
        player.rotation += (player.velocity.x / PLAYER_RADIUS) * 57.2958f;
    }

    Vector2 oldPosition = player.position;
    player.position.x += player.velocity.x;
    player.position.y += player.velocity.y;
    player.onGround = false;

    float leftBoundary = player.startX - LEFT_BOUNDARY_OFFSET;
    if (player.position.x - PLAYER_RADIUS < leftBoundary) {
        player.position.x = leftBoundary + PLAYER_RADIUS;
        player.velocity.x = 0;
    }

    if (!player.gameCompleted && !player.isDead && currentGameState != STATE_LEVEL_TRANSITION) {
        Rectangle finishPole = platforms[PLATFORM_COUNT].rect;
        Rectangle playerRect = {
            player.position.x - PLAYER_RADIUS,
            player.position.y - PLAYER_RADIUS,
            PLAYER_RADIUS * 2,
            PLAYER_RADIUS * 2
        };

        if (CheckCollisionRecs(playerRect, finishPole)) {
            player.velocity.x = 0;
            player.velocity.y = 0;
            if (currentLevel == 1) {
                level1Coins = player.coins; // 1. seviye coinlerini sakla
                currentLevel = 2;
                currentGameState = STATE_LEVEL_TRANSITION;
                levelTransitionTimer = levelTransitionDuration;
                timeStopped = true; // Seviye geçişinde zamanı durdur
                endTime = time(NULL); // Mevcut zamanı sabitle
                level1EndTime = (time_t)difftime(endTime, startTime); // Seviye 1'in süresini kaydet
                return;
            }
            else if (currentLevel == 2) {
                player.gameCompleted = true;
                timeStopped = true;
                endTime = time(NULL);

                if (strlen(currentPlayerName) > 0) {
                    int finalTime = (int)difftime(endTime, startTime);
                    float timeBonus = (finalTime > 0) ? (1000.0f / (float)finalTime) : 0.0f; // Sıfır bölme koruması
                    float score = (float)player.coins * 10.0f + timeBonus;
                    if (currentLevel == 2 && player.coins >= maxCoins) { // 2. seviyede tüm coinler için bonus
                        score += 50.0f;
                    }
                    UpdatePlayerScore(currentPlayerName, score);
                    SaveGameSettings();
                }
                return;
            }
        }
    }

    for (int i = 0; i < segmentCount; i++) {
        HandleRectangleCollision(&player.position, &player.velocity, oldPosition, PLAYER_RADIUS, groundSegments[i], &player.onGround, false);
    }

    // İtilebilir kutu ile çarpışma
    if (currentLevel == 2) {
        // Oyuncunun kutuya soldan yaklaşıp yaklaşmadığını kontrol et
        bool isPushingFromLeft = (player.position.x + PLAYER_RADIUS <= pushableBox.rect.x + 10 &&
            player.velocity.x > 0 &&
            oldPosition.x + PLAYER_RADIUS <= pushableBox.rect.x + 10);

        // Çarpışma kontrolü
        if (CheckCollisionCircleRect(player.position, PLAYER_RADIUS, pushableBox.rect)) {
            // Kutu itiliyorsa, önce kutuyu hareket ettir
            if (isPushingFromLeft) {
                float newBoxX = pushableBox.rect.x + player.velocity.x;
                bool collisionWithObstacle = false;

                // Engel çarpışma kontrolü
                Rectangle newBoxRect = pushableBox.rect;
                newBoxRect.x = newBoxX;
                for (int i = 0; i < segmentCount; i++) {
                    if (CheckCollisionRecs(newBoxRect, groundSegments[i])) {
                        collisionWithObstacle = true;
                        newBoxX = groundSegments[i].x - pushableBox.rect.width;
                        break;
                    }
                }
                if (!collisionWithObstacle && CheckCollisionRecs(newBoxRect, platforms[PLATFORM_COUNT].rect)) {
                    collisionWithObstacle = true;
                    newBoxX = platforms[PLATFORM_COUNT].rect.x - pushableBox.rect.width;
                }

                // Kutu hareket edebilir mi?
                if (!collisionWithObstacle && newBoxX <= pushableBox.rightBound) {
                    pushableBox.rect.x = newBoxX;
                    player.position.x = pushableBox.rect.x - PLAYER_RADIUS;
                }
                else {
                    player.position.x = pushableBox.rect.x - PLAYER_RADIUS;
                    player.velocity.x = 0;
                }
            }

            // Çarpışma çözümlemesi (her durumda uygulanır)
            HandleRectangleCollision(&player.position, &player.velocity, oldPosition, PLAYER_RADIUS, pushableBox.rect, &player.onGround, false);
        }
    }

    for (int i = 0; i < PLATFORM_COUNT; i++) {
        HandleRectangleCollision(&player.position, &player.velocity, oldPosition, PLAYER_RADIUS, platforms[i].rect, &player.onGround, true);
    }

    for (int i = 0; i < ROCK_COUNT; i++) {
        HandleRectangleCollision(&player.position, &player.velocity, oldPosition, PLAYER_RADIUS, rocks[i].rect, &player.onGround, false);
    }

    if (CheckPlayerInGap(player.position, PLAYER_RADIUS)) {
        if (!player.isDeathAnimating) {
            if (soundOn) PlaySound(fallSound); // Boşluğa düşme sesi
            player.lives = 0;
            player.isDead = true; // Hemen isDead durumunu true yap
            player.isDeathAnimating = true;
            player.deathEffectTimer = 0.0f;
            player.deathRotation = 0.0f;
            player.velocity.y = JUMP_FORCE / 2; // Yukarı sıçrama
            player.velocity.x = 0; // Yatay hareketi durdur
            currentGameState = STATE_GAME_OVER; // Hemen oyun biter
        }
    }

    for (int i = 0; i < BOT_COUNT; i++) {
        if (!bots[i].alive) continue;

        Vector2 previousPos = { bots[i].rect.x, bots[i].rect.y };
        float newX = bots[i].rect.x + bots[i].direction * bots[i].speed;

        // Rotasyon güncelleme: Karenin bir kenar uzunluğu kadar hareket ettiğinde 90 derece dönmesi için
        float rotationSpeed = (bots[i].speed / bots[i].rect.width) * 3600.0f;
        bots[i].rotation += (bots[i].direction > 0 ? rotationSpeed : -rotationSpeed) * GetFrameTime();

        if (newX <= bots[i].leftBound || newX + bots[i].rect.width >= bots[i].rightBound) {
            bots[i].direction *= -1;
            newX = bots[i].rect.x + bots[i].direction * bots[i].speed;
            bots[i].stuckTimer = 0.0f;
        }

        Rectangle newBotRect = bots[i].rect;
        newBotRect.x = newX;

        bool hitObstacle = false;

        for (int j = 0; j < ROCK_COUNT; j++) {
            if (CheckCollisionRecs(newBotRect, rocks[j].rect)) {
                hitObstacle = true;
                bots[i].direction *= -1;
                if (bots[i].direction == 1) {
                    bots[i].rect.x = rocks[j].rect.x - bots[i].rect.width - 2;
                }
                else {
                    bots[i].rect.x = rocks[j].rect.x + rocks[j].rect.width + 2;
                }
                bots[i].stuckTimer = 0.0f;
                break;
            }
        }

        if (!hitObstacle) {
            for (int g = 0; g < GAP_COUNT; g++) {
                if (gaps[g].active) {
                    float botCenter = newX + bots[i].rect.width / 2;
                    if (botCenter > gaps[g].startX - 30 && botCenter < gaps[g].endX + 30) {
                        hitObstacle = true;
                        bots[i].direction *= -1;
                        bots[i].stuckTimer = 0.0f;
                        break;
                    }
                }
            }
        }

        if (!hitObstacle) {
            float moveDistance = fabsf(newX - previousPos.x);
            if (moveDistance < 0.1f) {
                bots[i].stuckTimer += deltaTime;
                if (bots[i].stuckTimer > 1.5f) {
                    bots[i].direction *= -1;
                    bots[i].stuckTimer = 0.0f;
                }
            }
            else {
                bots[i].stuckTimer = 0.0f;
            }
            bots[i].rect.x = newX;
        }

        bots[i].lastPosition = (Vector2){ bots[i].rect.x, bots[i].rect.y };

        if (CheckCollisionCircleRect(player.position, PLAYER_RADIUS, bots[i].rect)) {
            bool topCollision = (oldPosition.y + PLAYER_RADIUS <= bots[i].rect.y + 5) &&
                (player.velocity.y >= 0) &&
                (player.position.x + PLAYER_RADIUS > bots[i].rect.x + 5) &&
                (player.position.x - PLAYER_RADIUS < bots[i].rect.x + bots[i].rect.width - 5);

            if (topCollision) {
                bots[i].alive = false;
                player.velocity.y = JUMP_FORCE / 2;
                player.coins++;
                if (soundOn) PlaySound(botKillSound);

            }
            else if (player.invulnerabilityTimer <= 0 && !player.isDead && player.lives > 0) {
                if (player.lives == 1 && soundOn) {
                    PlaySound(fallSound); // BOT SON CANI ALIYORSA SES ÇALSIN
                }

                player.lives--;
                player.invulnerabilityTimer = 1.5f;
                player.velocity.x = (player.position.x < bots[i].rect.x + bots[i].rect.width / 2) ? -8 : 8;
                player.velocity.y = JUMP_FORCE / 3;

                if (player.lives <= 0) player.isDead = true;
            }

        }
    }

    // Coin collection for platforms
    for (int i = 0; i < PLATFORM_COUNT; i++) {
        if (!player.isDead && !player.isDeathAnimating &&
            platforms[i].hasCoin && !platforms[i].coinCollected) {

            Vector2 coinPos = { platforms[i].rect.x + platforms[i].rect.width / 2, platforms[i].rect.y - 15 };

            if (CheckCollisionCircleCircle(player.position, PLAYER_RADIUS, coinPos, COIN_RADIUS)) {
                platforms[i].coinCollected = true;
                player.coins++;
                if (soundOn) PlaySound(coinSound);
            }
        }
    }

    // Coin collection for extra coins
    for (int i = 0; i < 3; i++) {
        if (!player.isDead && !player.isDeathAnimating && !extraCoins[i].collected) {
            if (CheckCollisionCircleCircle(player.position, PLAYER_RADIUS, extraCoins[i].position, COIN_RADIUS)) {
                extraCoins[i].collected = true;
                player.coins++;
                if (soundOn) PlaySound(coinSound);
            }
        }
    }

    // Vanishing platform coin’i
    if (!player.isDead && !player.isDeathAnimating &&
        vanishingPlatform.isVisible &&
        vanishingPlatform.hasCoin &&
        !vanishingPlatform.coinCollected) {

        Vector2 coinPos = {
            vanishingPlatform.rect.x + vanishingPlatform.rect.width / 2,
            vanishingPlatform.rect.y - 15
        };

        if (CheckCollisionCircleCircle(player.position, PLAYER_RADIUS, coinPos, COIN_RADIUS)) {
            vanishingPlatform.coinCollected = true;
            player.coins++;
            if (soundOn) PlaySound(coinSound);
        }
    }
    if (player.position.y > SCREEN_HEIGHT + 100) {
        player.lives = 0;
        player.isDead = true;
    }

    camera.target = (Vector2){ player.position.x, SCREEN_HEIGHT / 2.0f };

    UpdateWaterAndBoxes(deltaTime);
}


void DrawGame(void) {
    ClearBackground(SKYBLUE);
    BeginMode2D(camera);
    DrawTexture(backgroundTexture, camera.target.x - SCREEN_WIDTH / 2, camera.target.y - SCREEN_HEIGHT / 2, WHITE);

    for (int i = 0; i < segmentCount; i++) {
        Rectangle seg = groundSegments[i];

        Rectangle src = {
            0, 0,
            groundTexture.width,
            groundTexture.height
        };

        Rectangle dest = {
            seg.x + seg.width / 2,
            seg.y + seg.height / 2,
            seg.width,
            seg.height
        };

        Vector2 origin = {
            seg.width / 2,
            seg.height / 2

        };
        if (groundSegments[i].x == 2300) {
            DrawTexturePro(wallTexture, src, dest, origin, 0.0f, WHITE);
        }
        else {
            DrawTexturePro(groundTexture, src, dest, origin, 0.0f, WHITE);

        }

    }
    for (int i = 0; i <= PLATFORM_COUNT; i++) {
        if (platforms[i].isFinishLine) {
            DrawFinishFlag(platforms[i].rect.x, platforms[i].rect.y);
        }
        else {
            Rectangle src = { 0, 0, (float)platformTexture.width, (float)platformTexture.height };
            Rectangle dest = {
                platforms[i].rect.x + platforms[i].rect.width / 2,
                platforms[i].rect.y + platforms[i].rect.height / 2,
                platforms[i].rect.width,
                platforms[i].rect.height
            };
            Vector2 origin = { platforms[i].rect.width / 2, platforms[i].rect.height / 2 };
            DrawTexturePro(platformTexture, src, dest, origin, 0.0f, WHITE);

            if (i < PLATFORM_COUNT && platforms[i].hasCoin && !platforms[i].coinCollected) {
                Vector2 c = { platforms[i].rect.x + platforms[i].rect.width / 2, platforms[i].rect.y - 15 };
                DrawCircleV(c, COIN_RADIUS, GOLD);
                DrawCircleLinesV(c, COIN_RADIUS, ORANGE);
            }
        }
    }

    // Draw extra coins
    for (int i = 0; i < 3; i++) {
        if (!extraCoins[i].collected) {
            DrawCircleV(extraCoins[i].position, COIN_RADIUS, GOLD);
            DrawCircleLinesV(extraCoins[i].position, COIN_RADIUS, ORANGE);
        }

    }
    for (int i = 0; i < ROCK_COUNT; i++) {
        Rectangle src = {
            0, 0,
            (float)rockTexture.width,
            (float)rockTexture.height
        };

        Rectangle dest = {
            rocks[i].rect.x + rocks[i].rect.width / 2,
            rocks[i].rect.y + rocks[i].rect.height / 2,
            rocks[i].rect.width,
            rocks[i].rect.height
        };

        Vector2 origin = {
            rocks[i].rect.width / 2,
            rocks[i].rect.height / 2
        };

        DrawTexturePro(rockTexture, src, dest, origin, 0.0f, WHITE);


    }
    if (currentLevel == 2) {
        // Sol yarı (açık kahverengi)
        Rectangle leftHalf = { pushableBox.rect.x, pushableBox.rect.y, pushableBox.rect.width / 2, pushableBox.rect.height };
        DrawRectangleRec(leftHalf, (Color) { 181, 101, 29, 255 }); // Açık kahverengi
        DrawRectangleLinesEx(leftHalf, 2, DARKBROWN);

        // Sağ yarı (koyu siyah)
        Rectangle rightHalf = { pushableBox.rect.x + pushableBox.rect.width / 2, pushableBox.rect.y, pushableBox.rect.width / 2, pushableBox.rect.height };
        DrawRectangleRec(rightHalf, BLACK);
        DrawRectangleLinesEx(rightHalf, 2, DARKGRAY);
    }

    for (int i = 0; i < BOT_COUNT; i++) {
        if (bots[i].alive) {
            Vector2 botCenter = {
                bots[i].rect.x + bots[i].rect.width / 2,
                bots[i].rect.y + bots[i].rect.height / 2
            };

            Rectangle src = {
                0, 0,
                (float)enemyTexture.width,
                (float)enemyTexture.height
            };

            Rectangle dest = {
                botCenter.x,
                botCenter.y,
                bots[i].rect.width,
                bots[i].rect.height
            };

            Vector2 origin = {
                bots[i].rect.width / 2,
                bots[i].rect.height / 2
            };

            DrawTexturePro(enemyTexture, src, dest, origin, bots[i].rotation, WHITE);
        }
    }

    if (player.invulnerabilityTimer > 0 && ((int)(player.invulnerabilityTimer * 10) % 2 == 0)) {
        // Flashing effect when invulnerable
    }
    else {
        Vector2 playerCenter = player.position;
        float finalRotation = player.rotation;

        if (player.isDeathAnimating) {
            finalRotation += player.deathRotation;
        }

        DrawCircleSector(playerCenter, PLAYER_RADIUS, finalRotation - 90, finalRotation + 270, 36, RED);
        DrawCircleSectorLines(playerCenter, PLAYER_RADIUS, finalRotation - 90, finalRotation + 270, 36, MAROON);

        float faceRotationRad = finalRotation * DEG2RAD;
        Vector2 eyeOffset = { 7, -5 };

        Vector2 eyeLeftRotated = {
            playerCenter.x + (eyeOffset.x * cosf(faceRotationRad) - eyeOffset.y * sinf(faceRotationRad)),
            playerCenter.y + (eyeOffset.x * sinf(faceRotationRad) + eyeOffset.y * cosf(faceRotationRad))
        };

        Vector2 eyeRightRotated = {
            playerCenter.x + (-eyeOffset.x * cosf(faceRotationRad) - eyeOffset.y * sinf(faceRotationRad)),
            playerCenter.y + (-eyeOffset.x * sinf(faceRotationRad) + eyeOffset.y * cosf(faceRotationRad))
        };

        DrawCircleV(eyeLeftRotated, 2, WHITE);
        DrawCircleV(eyeRightRotated, 2, WHITE);
        DrawCircleV(eyeLeftRotated, 1, BLACK);
        DrawCircleV(eyeRightRotated, 1, BLACK);

        Vector2 smileOffset = { 0, 3 };
        Vector2 smileCenter = {
            playerCenter.x + (smileOffset.x * cosf(faceRotationRad) - smileOffset.y * sinf(faceRotationRad)),
            playerCenter.y + (smileOffset.x * sinf(faceRotationRad) + smileOffset.y * cosf(faceRotationRad))
        };

        if (player.isDeathAnimating) {
            DrawCircleSector(smileCenter, 5,
                finalRotation + 180,
                finalRotation + 360,
                8, BLACK);
        }
        else {
            DrawCircleSector(smileCenter, 5,
                finalRotation,
                finalRotation + 180,
                8, BLACK);
        }
    }

    DrawWaterAndBoxes();

    EndMode2D();

    for (int i = 0; i < MAX_LIVES; i++) {
        Texture2D icon = (i < player.lives) ? heartFull : heartEmpty;
        DrawTexture(icon, 20 + i * (heartFull.width + 10), 0, WHITE);
    }

    // Yeni coin kutusu çizimi
    int coinSize = 36;
    int fontSize = 24;
    const char* coinLabel = "Coins:";
    int labelWidth = MeasureText(coinLabel, fontSize);

    DrawText(coinLabel, 20, 35, fontSize, GOLD); // Coins: yazısı

    DrawText(TextFormat("%d", player.coins), 30 + labelWidth, 35, fontSize, GOLD); // Coin sayısı

    DrawTexture(coinIcon, 25 + labelWidth + MeasureText(TextFormat("%d", player.coins), fontSize) + 5, 33, WHITE); // Coin görseli

    // Zaman gösterimi
    int displayTime;
    if (currentGameState == STATE_LEVEL_TRANSITION || player.gameCompleted || player.isDead) {
        displayTime = (int)difftime(endTime, startTime); // Sabit zaman
    }
    else {
        displayTime = (int)difftime(time(NULL), startTime); // Gerçek zamanlı
    }
    DrawText(TextFormat("Time: %d", displayTime), 20, 60, 20, BLACK);

    if (showingLevelIntro) {
        DrawLevelIntro();
    }

    if (player.gameCompleted) {
        DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Fade(BLACK, 0.5f));
        DrawText("CONGRATULATIONS!", SCREEN_WIDTH / 2 - 150, SCREEN_HEIGHT / 2 - 80, 30, GREEN);
        DrawText(TextFormat("You collected %d/%d coins!", player.coins, maxCoins), SCREEN_WIDTH / 2 - 120, SCREEN_HEIGHT / 2 - 40, 20, WHITE);
        int finalTime = (int)difftime(endTime, startTime);
        DrawText(TextFormat("Time: %d seconds", finalTime), SCREEN_WIDTH / 2 - 80, SCREEN_HEIGHT / 2 - 10, 20, WHITE);
        DrawText("Press R to restart", SCREEN_WIDTH / 2 - 80, SCREEN_HEIGHT / 2 + 20, 20, WHITE);
        DrawText("Press DOWN to return to menu", SCREEN_WIDTH / 2 - 110, SCREEN_HEIGHT / 2 + 50, 20, WHITE);
    }

    if (player.isDead) {
        DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Fade(BLACK, 0.5f));
        DrawText("GAME OVER", SCREEN_WIDTH / 2 - 100, SCREEN_HEIGHT / 2 - 40, 30, RED);
        DrawText("Press R to restart", SCREEN_WIDTH / 2 - 80, SCREEN_HEIGHT / 2, 20, WHITE);
        DrawText("Press DOWN to return to menu", SCREEN_WIDTH / 2 - 110, SCREEN_HEIGHT / 2 + 30, 20, WHITE);
    }

    if (currentGameState == STATE_LEVEL_TRANSITION) {
        DrawRectangle(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, Fade(BLACK, 0.7f));

        const char* levelText = TextFormat("LEVEL %d COMPLETED!", currentLevel - 1);
        int fontSize = 40;
        Vector2 textSize = MeasureTextEx(GetFontDefault(), levelText, fontSize, 2);
        DrawText(levelText,
            SCREEN_WIDTH / 2 - textSize.x / 2,
            SCREEN_HEIGHT / 2 - 60,
            fontSize,
            WHITE);

        const char* scoreText = TextFormat("Current Score: %d coins", player.coins);
        Vector2 scoreSize = MeasureTextEx(GetFontDefault(), scoreText, 30, 2);
        DrawText(scoreText,
            SCREEN_WIDTH / 2 - scoreSize.x / 2,
            SCREEN_HEIGHT / 2,
            30,
            GOLD);

        const char* nextText = TextFormat("LOADING LEVEL %d...", currentLevel);
        Vector2 nextSize = MeasureTextEx(GetFontDefault(), nextText, 30, 2);
        DrawText(nextText,
            SCREEN_WIDTH / 2 - nextSize.x / 2,
            SCREEN_HEIGHT / 2 + 40,
            30,
            WHITE);
    }

    DrawText(TextFormat("Level: %d", currentLevel), 22, 83, 20, BLACK);
}

void InitializeMenuButtons(void) {
    int menuY = 250;
    int spacing = 60;
    int buttonWidth = 300;
    int buttonHeight = 40;DrawTexture(menuBgTexture, 0, 0, WHITE);


    for (int i = 0; i < 4; i++) {
        menuButtons[i] = (Rectangle){
            SCREEN_WIDTH / 2 - buttonWidth / 2,
            menuY + spacing * i,
            buttonWidth,
            buttonHeight
        };
        menuButtonHover[i] = false;
    }
}

void InitializeMenuAssets(void) {
    menuBgTexture = LoadTexture("menu_bg.g");
}
void UnloadMenuAssets(void) {
    UnloadFont(gameFont);
    UnloadTexture(menuBgTexture);
}

void DrawMenu(void) {
    ClearBackground(SKYBLUE);

    DrawRectangleGradientV(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
        (Color) {
        135, 206, 235, 255
    },
        (Color) {
        65, 105, 225, 255
    });

    float time = (float)GetTime();
    titleRotation = sinf(time * 2) * 5.0f;

    float scale = (sinf(time * 2) * 0.1f) + 1.0f;
    int baseRadius = 30;
    Color circleColor = RED;

    DrawCircle(SCREEN_WIDTH / 2 - 250, 120, baseRadius * scale, circleColor);
    DrawCircle(SCREEN_WIDTH / 2 + 250, 120, baseRadius * scale, circleColor);

    DrawLineEx((Vector2) { SCREEN_WIDTH / 2 - 250, 120 },
        (Vector2) {
        SCREEN_WIDTH / 2 + 250, 120
    },
        5, (Color) { 200, 40, 40, 100 });

    Vector2 titlePos = { SCREEN_WIDTH / 2, 120 };
    float fontSize = 60.0f;
    const char* title = "RED BALL 4";
    Vector2 textSize = MeasureTextEx(GetFontDefault(), title, fontSize, 2);

    Vector2 origin = { textSize.x / 2, textSize.y / 2 };
    DrawTextPro(GetFontDefault(), title,
        (Vector2) {
        titlePos.x + 4, titlePos.y + 4
    }, origin,
        titleRotation, fontSize, 2, (Color) { 0, 0, 0, 128 });
    DrawTextPro(GetFontDefault(), title,
        titlePos, origin,
        titleRotation, fontSize, 2, RED);

    const char* menuOptions[] = { "Start Game (1)", "Settings (2)", "Leaderboard (3)", "Exit (4)" };
    Vector2 mousePoint = GetMousePosition();
    static bool shouldClose = false; // Yerel kapanma bayrağı

    for (int i = 0; i < 4; i++) {
        float buttonScale = menuButtonHover[i] ? 1.1f : 1.0f;
        float yOffset = menuButtonHover[i] ? -2.0f : 0.0f;

        Rectangle buttonRect = {
            SCREEN_WIDTH / 2 - (menuButtons[i].width * buttonScale) / 2,
            menuButtons[i].y + yOffset,
            menuButtons[i].width * buttonScale,
            menuButtons[i].height
        };

        Rectangle collisionRect = {
            SCREEN_WIDTH / 2 - (menuButtons[i].width * 1.1f) / 2,
            menuButtons[i].y - 2.0f,
            menuButtons[i].width * 1.1f,
            menuButtons[i].height + 4.0f
        };

        menuButtonHover[i] = CheckCollisionPointRec(mousePoint, collisionRect);

        if (menuButtonHover[i] && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
            switch (i) {
            case 0:
                currentGameState = STATE_ENTER_NAME;
                strcpy(nameErrorMessage, "");
                break;
            case 1:
                currentGameState = STATE_SETTINGS;
                break;
            case 2:
                currentGameState = STATE_LEADERBOARD;
                break;
            case 3:
                SaveGameSettings();
                shouldClose = true; // Kapanma bayrağını true yap
                break;
            }
        }

        Color buttonColor = menuButtonHover[i] ? (Color) { 230, 41, 55, 255 } : (Color) { 255, 255, 255, 220 };
        Color gradientEnd = (Color){ buttonColor.r, buttonColor.g, buttonColor.b, 180 };

        if (menuButtonHover[i]) {
            DrawRectangleGradientH(buttonRect.x - 5, buttonRect.y - 5,
                buttonRect.width + 10, buttonRect.height + 10,
                (Color) {
                230, 41, 55, 50
            }, (Color) { 230, 41, 55, 0 });
        }

        DrawRectangleGradientH(buttonRect.x, buttonRect.y,
            buttonRect.width, buttonRect.height,
            buttonColor, gradientEnd);
        DrawRectangleLinesEx(buttonRect, 2, menuButtonHover[i] ? WHITE : (Color) { 70, 70, 70, 255 });

        const char* text = menuOptions[i];
        float textSize = 25.0f * buttonScale;
        Vector2 textDim = MeasureTextEx(GetFontDefault(), text, textSize, 1);
        float textX = buttonRect.x + (buttonRect.width - textDim.x) / 2;
        float textY = buttonRect.y + (buttonRect.height - textDim.y) / 2;

        DrawText(text, textX + 2, textY + 2, textSize, (Color) { 0, 0, 0, 128 });
        DrawText(text, textX, textY, textSize, menuButtonHover[i] ? WHITE : BLACK);
    }

    if (shouldClose) {
        SaveGameSettings();
        UnloadMenuAssets();
        CloseWindow();
        exit(0); // Programı sonlandır
    }

    Rectangle infoBox;
    if (nameSet) {
        infoBox = (Rectangle){ 5, SCREEN_HEIGHT - 70, 400, 60 };
        DrawRectangleGradientV(infoBox.x, infoBox.y, infoBox.width, infoBox.height,
            (Color) {
            0, 0, 0, 180
        }, (Color) { 0, 0, 0, 100 });
        DrawRectangleLinesEx(infoBox, 2, (Color) { 255, 255, 255, 128 });
        DrawText(TextFormat("Current Player: %s", currentPlayerName), 15, SCREEN_HEIGHT - 60, 20, WHITE);
        float bestScore = GetPlayerBestScore(currentPlayerName);
        DrawText(TextFormat("Best Score: %.1f", bestScore), 15, SCREEN_HEIGHT - 35, 20, WHITE);
    }
    else {
        infoBox = (Rectangle){ 5, SCREEN_HEIGHT - 45, 300, 35 };
        DrawRectangleGradientV(infoBox.x, infoBox.y, infoBox.width, infoBox.height,
            (Color) {
            0, 0, 0, 180
        }, (Color) { 0, 0, 0, 100 });
        DrawRectangleLinesEx(infoBox, 2, (Color) { 255, 255, 255, 128 });
        DrawText("No player selected", 15, SCREEN_HEIGHT - 35, 20, WHITE);
    }

    const char* instructText = "Use arrow keys or WASD to move, SPACE to jump";
    int textWidth = MeasureText(instructText, 20);
    Rectangle instructBox = {
        SCREEN_WIDTH / 2 - (textWidth + 100) / 2,
        SCREEN_HEIGHT - 60,
        textWidth + 100,
        40
    };

    DrawRectangleGradientH(instructBox.x, instructBox.y, instructBox.width, instructBox.height,
        (Color) {
        0, 0, 0, 180
    }, (Color) { 0, 0, 0, 100 });
    DrawRectangleLinesEx(instructBox, 2, (Color) { 255, 255, 255, 128 });

    DrawRectangleRounded((Rectangle) { instructBox.x + 10, instructBox.y + 5, 30, 30 }, 0.3f, 8, WHITE);
    DrawText("⌨", instructBox.x + 15, instructBox.y + 7, 20, BLACK);

    DrawText(instructText, instructBox.x + 50, instructBox.y + 10, 20, WHITE);
}

void HandleMenuInput(bool* shouldClose) {
    if (IsKeyPressed(KEY_ONE)) {
        currentGameState = STATE_ENTER_NAME;
        strcpy(nameErrorMessage, "");
    }
    else if (IsKeyPressed(KEY_TWO)) {
        currentGameState = STATE_SETTINGS;
    }
    else if (IsKeyPressed(KEY_THREE)) {
        currentGameState = STATE_LEADERBOARD;
    }
    else if (IsKeyPressed(KEY_FOUR)) {
        SaveGameSettings();
        *shouldClose = true; // Kapanma bayrağını true yap
    }
}

void DrawSettings(void) {
    ClearBackground(SKYBLUE);

    DrawRectangleGradientV(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
        (Color) {
        135, 206, 235, 255
    },
        (Color) {
        65, 105, 225, 255
    });

    DrawText("SETTINGS", SCREEN_WIDTH / 2 - 78, 102, 30, (Color) { 30, 30, 30, 128 });
    DrawText("SETTINGS", SCREEN_WIDTH / 2 - 80, 100, 30, RED);

    static Rectangle settingButtons[3];
    static bool settingButtonHover[3] = { false, false, false };
    const char* settingOptions[] = {
        "Enter Player Name (1)",
        TextFormat("Sound: %s (2)", soundOn ? "ON" : "OFF"),
        "Back to Menu (3)"
    };

    int settingsY = 200;
    int spacing = 60;
    int buttonWidth = 300;
    int buttonHeight = 40;

    Vector2 mousePoint = GetMousePosition();

    for (int i = 0; i < 3; i++) {
        settingButtons[i] = (Rectangle){
            SCREEN_WIDTH / 2 - buttonWidth / 2,
            settingsY + spacing * i,
            buttonWidth,
            buttonHeight
        };

        Rectangle collisionRect = {
            SCREEN_WIDTH / 2 - (buttonWidth * 1.1f) / 2,
            settingButtons[i].y - 2.0f,
            buttonWidth * 1.1f,
            buttonHeight + 4.0f
        };

        settingButtonHover[i] = CheckCollisionPointRec(mousePoint, collisionRect);

        if (settingButtonHover[i] && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
            switch (i) {
            case 0:
                currentGameState = STATE_ENTER_NAME;
                strcpy(nameErrorMessage, "");
                break;
            case 1:
                soundOn = !soundOn;
                SaveGameSettings();
                break;
            case 2:
                currentGameState = STATE_MENU;
                break;
            }
        }

        float buttonScale = settingButtonHover[i] ? 1.1f : 1.0f;
        float yOffset = settingButtonHover[i] ? -2.0f : 0.0f;

        Rectangle buttonRect = {
            SCREEN_WIDTH / 2 - (buttonWidth * buttonScale) / 2,
            settingButtons[i].y + yOffset,
            buttonWidth * buttonScale,
            buttonHeight
        };

        Color buttonColor = settingButtonHover[i] ? (Color) { 230, 41, 55, 255 } : (Color) { 255, 255, 255, 220 };

        if (settingButtonHover[i]) {
            DrawRectangleGradientH(buttonRect.x - 5, buttonRect.y - 5,
                buttonRect.width + 10, buttonRect.height + 10,
                (Color) {
                230, 41, 55, 50
            }, (Color) { 230, 41, 55, 0 });
        }

        DrawRectangleGradientH(buttonRect.x, buttonRect.y,
            buttonRect.width, buttonRect.height,
            buttonColor, (Color) { buttonColor.r, buttonColor.g, buttonColor.b, 180 });
        DrawRectangleLinesEx(buttonRect, 2, settingButtonHover[i] ? WHITE : (Color) { 70, 70, 70, 255 });

        Vector2 textDim = MeasureTextEx(GetFontDefault(), settingOptions[i], 25 * buttonScale, 1);
        float textX = buttonRect.x + (buttonRect.width - textDim.x) / 2;
        float textY = buttonRect.y + (buttonRect.height - textDim.y) / 2;

        DrawText(settingOptions[i], textX + 2, textY + 2, 25 * buttonScale, (Color) { 0, 0, 0, 128 });
        DrawText(settingOptions[i], textX, textY, 25 * buttonScale, settingButtonHover[i] ? WHITE : BLACK);
    }

    if (nameSet) {
        Rectangle infoBox = (Rectangle){ SCREEN_WIDTH / 2 - 150, settingsY + spacing * 3, 300, 40 };
        DrawRectangleGradientH(infoBox.x, infoBox.y, infoBox.width, infoBox.height,
            (Color) {
            0, 0, 0, 180
        }, (Color) { 0, 0, 0, 100 });
        DrawRectangleLinesEx(infoBox, 2, (Color) { 255, 255, 255, 128 });
        DrawText(TextFormat("Current Player: %s", currentPlayerName),
            infoBox.x + 10, infoBox.y + 10, 20, WHITE);
    }
}

void HandleSettingsInput(void) {
    if (IsKeyPressed(KEY_ONE)) {
        currentGameState = STATE_ENTER_NAME;
        strcpy(nameErrorMessage, "");
    }
    else if (IsKeyPressed(KEY_TWO)) {
        soundOn = !soundOn;
        SaveGameSettings();
    }
    else if (IsKeyPressed(KEY_THREE)) {
        currentGameState = STATE_MENU;
    }
}

void HandleEnterNameInput(void) {
    int key = GetCharPressed();
    while (key > 0) {
        if (strlen(currentPlayerName) < MAX_NAME_LENGTH) {
            if ((key >= 'A' && key <= 'Z') || (key >= 'a' && key <= 'z') || (key >= '0' && key <= '9')) {
                int len = strlen(currentPlayerName);
                currentPlayerName[len] = (char)key;
                currentPlayerName[len + 1] = '\0';
                strcpy(nameErrorMessage, "");
            }
        }
        key = GetCharPressed();
    }

    if (IsKeyPressed(KEY_BACKSPACE)) {
        int len = strlen(currentPlayerName);
        if (len > 0) {
            currentPlayerName[len - 1] = '\0';
            strcpy(nameErrorMessage, "");
        }
    }

    if (IsKeyPressed(KEY_ENTER)) {
        if (strlen(currentPlayerName) > 0) {
            if (IsValidPlayerName(currentPlayerName)) {
                nameSet = true;
                if (!PlayerNameExists(currentPlayerName)) {
                    AddNewPlayer(currentPlayerName);
                }
                SaveGameSettings();
                currentGameState = STATE_PLAYING;
                InitializeGame();
            }
            else {
                strcpy(nameErrorMessage, "Invalid characters! Use only letters and numbers.");
            }
        }
        else {
            strcpy(nameErrorMessage, "Name cannot be empty!");
        }
    }
}

void DrawEnterName(void) {
    ClearBackground(SKYBLUE);

    DrawRectangleGradientV(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
        (Color) {
        135, 206, 235, 255
    },
        (Color) {
        65, 105, 225, 255
    });

    const char* titleText = "ENTER PLAYER NAME";
    int titleWidth = MeasureText(titleText, 40);
    Rectangle titleBox = {
        SCREEN_WIDTH / 2 - (titleWidth + 60) / 2,
        80,
        titleWidth + 60,
        60
    };

    DrawRectangleGradientH(titleBox.x - 5, titleBox.y - 5,
        titleBox.width + 10, titleBox.height + 10,
        (Color) {
        230, 41, 55, 30
    }, (Color) { 230, 41, 55, 0 });
    DrawRectangleGradientH(titleBox.x, titleBox.y,
        titleBox.width, titleBox.height,
        (Color) {
        0, 0, 0, 180
    }, (Color) { 0, 0, 0, 100 });
    DrawRectangleLinesEx(titleBox, 2, (Color) { 255, 255, 255, 128 });

    DrawText(titleText,
        titleBox.x + (titleBox.width - titleWidth) / 2 + 2,
        titleBox.y + (titleBox.height - 40) / 2 + 2,
        40, (Color) { 0, 0, 0, 128 });
    DrawText(titleText,
        titleBox.x + (titleBox.width - titleWidth) / 2,
        titleBox.y + (titleBox.height - 40) / 2,
        40, WHITE);

    const char* instructText = "Enter your name (max 15 characters, alphanumeric only):";
    int instructWidth = MeasureText(instructText, 20);
    Rectangle instructBox = {
        SCREEN_WIDTH / 2 - (instructWidth + 40) / 2,
        180,
        instructWidth + 40,
        40
    };

    DrawRectangleGradientH(instructBox.x - 5, instructBox.y - 5,
        instructBox.width + 10, instructBox.height + 10,
        (Color) {
        230, 41, 55, 30
    }, (Color) { 230, 41, 55, 0 });
    DrawRectangleGradientH(instructBox.x, instructBox.y,
        instructBox.width, instructBox.height,
        (Color) {
        0, 0, 0, 180
    }, (Color) { 0, 0, 0, 100 });
    DrawRectangleLinesEx(instructBox, 2, (Color) { 255, 255, 255, 128 });

    DrawText(instructText,
        instructBox.x + 20,
        instructBox.y + (instructBox.height - 20) / 2,
        20, WHITE);

    Rectangle inputBox = {
        SCREEN_WIDTH / 2 - 200,
        250,
        400,
        50
    };

    DrawRectangleGradientH(inputBox.x - 5, inputBox.y - 5,
        inputBox.width + 10, inputBox.height + 10,
        (Color) {
        230, 41, 55, 30
    }, (Color) { 230, 41, 55, 0 });
    DrawRectangleRec(inputBox, WHITE);
    DrawRectangleLinesEx(inputBox, 2, BLACK);

    int textWidth = MeasureText(currentPlayerName, 25);
    DrawText(currentPlayerName, inputBox.x + 10, inputBox.y + 12, 25, BLACK);

    if (((int)(GetTime() * 2)) % 2 == 0) {
        DrawText("_", inputBox.x + 10 + textWidth, inputBox.y + 12, 25, BLACK);
    }

    const char* controlsText = "Press ENTER to confirm";
    int controlsWidth = MeasureText(controlsText, 20);
    Rectangle controlsBox = {
        SCREEN_WIDTH / 2 - (controlsWidth + 60) / 2,
        330,
        controlsWidth + 60,
        60
    };

    DrawRectangleGradientH(controlsBox.x - 5, controlsBox.y - 5,
        controlsBox.width + 10, controlsBox.height + 10,
        (Color) {
        230, 41, 55, 30
    }, (Color) { 230, 41, 55, 0 });
    DrawRectangleGradientH(controlsBox.x, controlsBox.y,
        controlsBox.width, controlsBox.height,
        (Color) {
        0, 0, 0, 180
    }, (Color) { 0, 0, 0, 100 });
    DrawRectangleLinesEx(controlsBox, 2, (Color) { 255, 255, 255, 128 });

    DrawText(controlsText,
        controlsBox.x + (controlsBox.width - controlsWidth) / 2 + 2,
        controlsBox.y + (controlsBox.height - 20) / 2 + 2,
        20, (Color) { 0, 0, 0, 128 });
    DrawText(controlsText,
        controlsBox.x + (controlsBox.width - controlsWidth) / 2,
        controlsBox.y + (controlsBox.height - 20) / 2,
        20, WHITE);

    if (strlen(nameErrorMessage) > 0) {
        int errorWidth = MeasureText(nameErrorMessage, 20);
        Rectangle errorBox = {
            SCREEN_WIDTH / 2 - (errorWidth + 40) / 2,
            400,
            errorWidth + 40,
            40
        };

        DrawRectangleGradientH(errorBox.x - 5, errorBox.y - 5,
            errorBox.width + 10, errorBox.height + 10,
            (Color) {
            230, 41, 55, 30
        }, (Color) { 230, 41, 55, 0 });
        DrawRectangleGradientH(errorBox.x, errorBox.y,
            errorBox.width, errorBox.height,
            (Color) {
            230, 41, 55, 180
        }, (Color) { 230, 41, 55, 100 });
        DrawRectangleLinesEx(errorBox, 2, (Color) { 255, 255, 255, 128 });

        DrawText(nameErrorMessage,
            errorBox.x + 20,
            errorBox.y + (errorBox.height - 20) / 2,
            20, WHITE);
    }
    static bool menuButtonHover = false;
    Rectangle menuButton = {
        SCREEN_WIDTH / 2 - 150,
        SCREEN_HEIGHT - 80,
        300,
        40
    };

    Vector2 mousePoint = GetMousePosition();
    menuButtonHover = CheckCollisionPointRec(mousePoint, menuButton);

    if (menuButtonHover && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        currentGameState = STATE_MENU;
        strcpy(nameErrorMessage, "");
    }

    float buttonScale = menuButtonHover ? 1.1f : 1.0f;
    float yOffset = menuButtonHover ? -2.0f : 0.0f;

    Rectangle buttonRect = {
        menuButton.x - (menuButton.width * (buttonScale - 1.0f) / 2),
        menuButton.y + yOffset,
        menuButton.width * buttonScale,
        menuButton.height
    };

    if (menuButtonHover) {
        DrawRectangleGradientH(buttonRect.x - 5, buttonRect.y - 5,
            buttonRect.width + 10, buttonRect.height + 10,
            (Color) {
            230, 41, 55, 50
        }, (Color) { 230, 41, 55, 0 });
    }

    Color buttonColor = menuButtonHover ? (Color) { 230, 41, 55, 255 } : (Color) { 255, 255, 255, 220 };
    DrawRectangleGradientH(buttonRect.x, buttonRect.y,
        buttonRect.width, buttonRect.height,
        buttonColor, (Color) { buttonColor.r, buttonColor.g, buttonColor.b, 180 });
    DrawRectangleLinesEx(buttonRect, 2, menuButtonHover ? WHITE : (Color) { 70, 70, 70, 255 });

    const char* buttonText = "Return to Menu";
    float textSize = 25.0f * buttonScale;
    Vector2 textDim = MeasureTextEx(GetFontDefault(), buttonText, textSize, 1);
    float textX = buttonRect.x + (buttonRect.width - textDim.x) / 2;
    float textY = buttonRect.y + (buttonRect.height - textDim.y) / 2;

    DrawText(buttonText, textX + 2, textY + 2, textSize, (Color) { 0, 0, 0, 128 });
    DrawText(buttonText, textX, textY, textSize, menuButtonHover ? WHITE : BLACK);
}

void DrawLeaderboard(void) {
    ClearBackground(SKYBLUE);

    DrawRectangleGradientV(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT,
        (Color) {
        135, 206, 235, 255
    },
        (Color) {
        65, 105, 225, 255
    });

    DrawText("LEADERBOARD", SCREEN_WIDTH / 2 - 100, 50, 30, (Color) { 30, 30, 30, 128 });
    DrawText("LEADERBOARD", SCREEN_WIDTH / 2 - 102, 48, 30, BLACK);

    PlayerRecord sortedPlayers[MAX_PLAYERS];
    int validPlayers = 0;

    for (int i = 0; i < totalPlayers; i++) {
        if (playerRecords[i].exists && playerRecords[i].bestScore > 0) {
            sortedPlayers[validPlayers] = playerRecords[i];
            validPlayers++;
        }
    }

    for (int i = 0; i < validPlayers - 1; i++) {
        for (int j = 0; j < validPlayers - i - 1; j++) {
            if (sortedPlayers[j].bestScore < sortedPlayers[j + 1].bestScore) {
                PlayerRecord temp = sortedPlayers[j];
                sortedPlayers[j] = sortedPlayers[j + 1];
                sortedPlayers[j + 1] = temp;
            }
        }
    }

    static bool menuButtonHover = false;
    Rectangle menuButton = {
        SCREEN_WIDTH / 2 - 150,
        SCREEN_HEIGHT - 80,
        300,
        40
    };

    Vector2 mousePoint = GetMousePosition();
    menuButtonHover = CheckCollisionPointRec(mousePoint, menuButton);

    if (menuButtonHover && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
        currentGameState = STATE_MENU;
    }

    float buttonScale = menuButtonHover ? 1.1f : 1.0f;
    float yOffset = menuButtonHover ? -2.0f : 0.0f;

    Rectangle buttonRect = {
        menuButton.x - (menuButton.width * (buttonScale - 1.0f) / 2),
        menuButton.y + yOffset,
        menuButton.width * buttonScale,
        menuButton.height
    };

    if (menuButtonHover) {
        DrawRectangleGradientH(buttonRect.x - 5, buttonRect.y - 5,
            buttonRect.width + 10, buttonRect.height + 10,
            (Color) {
            230, 41, 55, 50
        }, (Color) { 230, 41, 55, 0 });
    }

    Color buttonColor = menuButtonHover ? (Color) { 230, 41, 55, 255 } : (Color) { 255, 255, 255, 220 };
    DrawRectangleGradientH(buttonRect.x, buttonRect.y,
        buttonRect.width, buttonRect.height,
        buttonColor, (Color) { buttonColor.r, buttonColor.g, buttonColor.b, 180 });
    DrawRectangleLinesEx(buttonRect, 2, menuButtonHover ? WHITE : (Color) { 70, 70, 70, 255 });

    const char* buttonText = "Return to Menu";
    float textSize = 25.0f * buttonScale;
    Vector2 textDim = MeasureTextEx(GetFontDefault(), buttonText, textSize, 1);
    float textX = buttonRect.x + (buttonRect.width - textDim.x) / 2;
    float textY = buttonRect.y + (buttonRect.height - textDim.y) / 2;

    DrawText(buttonText, textX + 2, textY + 2, textSize, (Color) { 0, 0, 0, 128 });
    DrawText(buttonText, textX, textY, textSize, menuButtonHover ? WHITE : BLACK);

    int startY = 120;
    int spacing = 35;

    if (validPlayers == 0) {
        DrawText("No scores recorded yet!", SCREEN_WIDTH / 2 - 120, startY + 50, 25, DARKGRAY);
    }
    else {
        DrawText("Rank    Player Name         Best Score", SCREEN_WIDTH / 2 - 200, startY, 20, BLACK);
        DrawLine(SCREEN_WIDTH / 2 - 200, startY + 25, SCREEN_WIDTH / 2 + 200, startY + 25, BLACK);

        for (int i = 0; i < validPlayers && i < 10; i++) {
            Color textColor = BLACK;
            if (strcmp(sortedPlayers[i].name, currentPlayerName) == 0) {
                textColor = RED;
            }

            DrawText(TextFormat("%d.", i + 1), SCREEN_WIDTH / 2 - 180, startY + 40 + i * spacing, 20, textColor);
            DrawText(sortedPlayers[i].name, SCREEN_WIDTH / 2 - 150, startY + 40 + i * spacing, 20, textColor);
            DrawText(TextFormat("%.1f", sortedPlayers[i].bestScore), SCREEN_WIDTH / 2 + 50, startY + 40 + i * spacing, 20, textColor);
        }
    }
}

void HandleGameInput(void) {
    if (IsKeyPressed(KEY_DOWN) && (player.gameCompleted || player.isDead)) {
        strcpy(currentPlayerName, "");
        nameSet = false;
        currentGameState = STATE_MENU;
    }
    if (IsKeyPressed(KEY_R) && (player.isDead || currentGameState == STATE_GAME_OVER)) {
        ResetGame(&player);
        if (currentLevel == 2) {
            startTime = time(NULL) - level1EndTime; // Seviye 1'in süresinden devam et
        }
        else {
            startTime = time(NULL); // Seviye 1 için sıfırla
        }
        timeStopped = false;
        showingLevelIntro = true;
        levelIntroTimer = 2.0f;
        levelIntroAlpha = 1.0f;
        currentGameState = STATE_PLAYING;
    }
}

void HandleLeaderboardInput(void) {
    //şimdilik boş
}

void ResetGame(Player* player) {
    player->position = (Vector2){ -20, SCREEN_HEIGHT - 300 };
    player->startX = player->position.x;
    player->velocity = (Vector2){ 0, 0 };
    player->onGround = false;
    player->lives = MAX_LIVES;
    if (currentLevel == 1) {
        player->coins = 0; // 1. seviyede coinler sıfırlanır
    }
    else if (currentLevel == 2) {
        player->coins = level1Coins; // 2. seviyede 1. seviye coinlerine dön
    }
    // 2. seviyede player->coins korunur
    player->rotation = 0.0f;
    player->isDead = false;
    player->gameCompleted = false;
    player->invulnerabilityTimer = 0.0f;
    player->deathEffectTimer = 0.0f;
    player->deathRotation = 0.0f;
    player->isDeathAnimating = false;
    maxCoins = 0;

    InitializeLevel();
}

bool IsValidPlayerName(const char* name) {
    if (strlen(name) > 15 || strlen(name) == 0) return false;
    for (int i = 0; name[i]; i++) {
        if (!((name[i] >= 'A' && name[i] <= 'Z') ||
            (name[i] >= 'a' && name[i] <= 'z') ||
            (name[i] >= '0' && name[i] <= '9'))) {
            return false;
        }
    }
    return true;
}

bool PlayerNameExists(const char* name) {
    for (int i = 0; i < totalPlayers; i++) {
        if (strcmp(playerRecords[i].name, name) == 0) {
            return true;
        }
    }
    return false;
}

int GetPlayerIndex(const char* name) {
    for (int i = 0; i < totalPlayers; i++) {
        if (strcmp(playerRecords[i].name, name) == 0) {
            return i;
        }
    }
    return -1;
}

void AddNewPlayer(const char* name) {
    if (!IsValidPlayerName(name)) {
        printf("Error: Invalid player name '%s'\n", name);
        return;
    }
    if (totalPlayers < MAX_PLAYERS) {
        if (PlayerNameExists(name)) return; // 🔒 Önlem: Aynı isimle 2. kez eklenmesin
        strcpy(playerRecords[totalPlayers].name, name);
        playerRecords[totalPlayers].bestScore = 0.0f;
        playerRecords[totalPlayers].exists = true;
        totalPlayers++;
    }
    else {
        printf("Error: Maximum player limit reached\n");
    }
}

void UpdatePlayerScore(const char* name, float score) {
    int index = GetPlayerIndex(name);
    if (index != -1) {
        if (score > playerRecords[index].bestScore) {
            playerRecords[index].bestScore = score;
        }
        TraceLog(LOG_WARNING, "⚠️ Oyuncu bulunamadı: %s", name);
    }
}

float GetPlayerBestScore(const char* name) {
    int index = GetPlayerIndex(name);
    if (index != -1) {
        return playerRecords[index].bestScore;
    }
    return 0.0f;
}

void SaveGameSettings(void) {
    FILE* file = fopen("player_records.dat", "wb");
    if (file != NULL) {
        fwrite(&totalPlayers, sizeof(int), 1, file);
        fwrite(playerRecords, sizeof(PlayerRecord), totalPlayers, file);
        fwrite(&currentPlayerName, sizeof(currentPlayerName), 1, file);
        fwrite(&nameSet, sizeof(bool), 1, file);
        fclose(file);
    }

    fprintf(file, "soundOn=%d\n", soundOn ? 1 : 0);
    int validPlayers = 0;
    for (int i = 0; i < totalPlayers; i++) {
        if (playerRecords[i].exists && IsValidPlayerName(playerRecords[i].name)) {
            validPlayers++;
        }
    }
    fprintf(file, "totalPlayers=%d\n", validPlayers);

    int playerIndex = 0;
    for (int i = 0; i < totalPlayers; i++) {
        if (playerRecords[i].exists && IsValidPlayerName(playerRecords[i].name)) {
            fprintf(file, "player_%d_name=%s\n", playerIndex, playerRecords[i].name);
            fprintf(file, "player_%d_score=%.1f\n", playerIndex, playerRecords[i].bestScore);
            playerIndex++;
        }
    }

    if (fclose(file) != 0) {
        printf("Error: Could not close save.txt\n");
    }
}

void LoadGameSettings(void) {
    FILE* file = fopen("player_records.dat", "rb");
    if (file != NULL) {
        fread(&totalPlayers, sizeof(int), 1, file);
        fread(playerRecords, sizeof(PlayerRecord), totalPlayers, file);
        fclose(file);
    }
    totalPlayers = 0;
    nameSet = false;
    strcpy(currentPlayerName, "");

     file = fopen("save.txt", "r");
    if (!file) {
        printf("Error: Could not open save.txt for reading\n");
        return;
    }

    char line[256];
    char key[64], value[64];
    int tempPlayers = 0;

    while (fgets(line, sizeof(line), file)) {
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') {
            line[len - 1] = '\0';
        }

        if (sscanf(line, "%[^=]=%[^\n]", key, value) == 2) {
            if (strcmp(key, "soundOn") == 0) {
                soundOn = atoi(value) != 0;
            }
            else if (strcmp(key, "totalPlayers") == 0) {
                tempPlayers = atoi(value);
                if (tempPlayers > MAX_PLAYERS) tempPlayers = MAX_PLAYERS;
            }
            else {
                int playerIndex;
                if (sscanf(key, "player_%d_name", &playerIndex) == 1) {
                    if (playerIndex >= 0 && playerIndex < MAX_PLAYERS && IsValidPlayerName(value)) {
                        strncpy(playerRecords[playerIndex].name, value, MAX_NAME_LENGTH);
                        playerRecords[playerIndex].name[MAX_NAME_LENGTH] = '\0';
                        playerRecords[playerIndex].exists = true;
                        if (playerIndex >= totalPlayers) totalPlayers = playerIndex + 1;
                    }
                }
                else if (sscanf(key, "player_%d_score", &playerIndex) == 1) {
                    if (playerIndex >= 0 && playerIndex < MAX_PLAYERS && playerRecords[playerIndex].exists) {
                        playerRecords[playerIndex].bestScore = atof(value);
                    }
                }
            }
        }
    }

    if (fclose(file) != 0) {
        printf("Error: Could not close save.txt\n");
    }

    // Geçersiz kayıtları temizle
    int validPlayers = 0;
    for (int i = 0; i < totalPlayers; i++) {
        if (playerRecords[i].exists && IsValidPlayerName(playerRecords[i].name)) {
            if (i != validPlayers) {
                strcpy(playerRecords[validPlayers].name, playerRecords[i].name);
                playerRecords[validPlayers].bestScore = playerRecords[i].bestScore;
                playerRecords[validPlayers].exists = true;
            }
            validPlayers++;
        }
    }
    totalPlayers = validPlayers;
}
void GenerateGaps(void) {
    if (currentLevel == 1) {
        gaps[0].startX = 520;
        gaps[0].endX = gaps[0].startX + GAP_WIDTH;
        gaps[0].active = true;

        gaps[1].startX = 1250;
        gaps[1].endX = gaps[1].startX + GAP_WIDTH;
        gaps[1].active = true;
    }
    else {
        gaps[0].startX = 1000;
        gaps[0].endX = gaps[0].startX + 580; // Uzun boşluk
        gaps[0].active = true;

        gaps[1].startX = 0;
        gaps[1].endX = 0;
        gaps[1].active = false; // İkinci boşluğu devre dışı bırak
    }
}

void GeneratePlatforms(void) {
    int groundLevel = SCREEN_HEIGHT - 40;

    if (currentLevel == 1) {
        // Platformlar (8 adet, her biri hasCoin = true)
        platforms[0].rect = (Rectangle){ 200, groundLevel - 80, 120, 20 };
        platforms[0].hasCoin = true;
        platforms[0].coinCollected = false;
        platforms[0].isFinishLine = false;
        platforms[1].rect = (Rectangle){ 380, groundLevel - 100, 120, 20 };
        platforms[1].hasCoin = true;
        platforms[1].coinCollected = false;
        platforms[1].isFinishLine = false;
        platforms[2].rect = (Rectangle){ 660, groundLevel - 120, 120, 20 };
        platforms[2].hasCoin = true;
        platforms[2].coinCollected = false;
        platforms[2].isFinishLine = false;
        platforms[3].rect = (Rectangle){ 860, groundLevel - 90, 120, 20 };
        platforms[3].hasCoin = true;
        platforms[3].coinCollected = false;
        platforms[3].isFinishLine = false;
        platforms[4].rect = (Rectangle){ 1100, groundLevel - 140, 120, 20 };
        platforms[4].hasCoin = true;
        platforms[4].coinCollected = false;
        platforms[4].isFinishLine = false;
        platforms[5].rect = (Rectangle){ 1390, groundLevel - 110, 120, 20 };
        platforms[5].hasCoin = true;
        platforms[5].coinCollected = false;
        platforms[5].isFinishLine = false;
        platforms[6].rect = (Rectangle){ 1590, groundLevel - 160, 120, 20 };
        platforms[6].hasCoin = true;
        platforms[6].coinCollected = false;
        platforms[6].isFinishLine = false;
        platforms[7].rect = (Rectangle){ 1790, groundLevel - 130, 120, 20 };
        platforms[7].hasCoin = true;
        platforms[7].coinCollected = false;
        platforms[7].isFinishLine = false;
    }
    else {
        for (int i = 0; i < PLATFORM_COUNT; i++) {
            platforms[i].rect = (Rectangle){ 0, 0, 0, 0 };
            platforms[i].hasCoin = false;
            platforms[i].coinCollected = false;
            platforms[i].isFinishLine = false;
        }
    }
    // Extra coins
    if (currentLevel == 1) {
        extraCoins[0].position = (Vector2){ 420, SCREEN_HEIGHT - 60 }; // Seviye 1 için yeni pozisyon
        extraCoins[0].collected = false;
    }
    else {
        extraCoins[0].position = (Vector2){ 300, SCREEN_HEIGHT - 60 }; // Seviye 2 için orijinal pozisyon
        extraCoins[0].collected = false;
    }
    if (currentLevel == 1) {
        extraCoins[1].position = (Vector2){ 1500, SCREEN_HEIGHT - 60 }; // Seviye 1 için orijinal pozisyon
    }
    else {
        extraCoins[1].position = (Vector2){ 1200, SCREEN_HEIGHT - 220 }; // Seviye 2 için yeni pozisyon
    }
    extraCoins[1].collected = false;    extraCoins[1].collected = false;
    if (currentLevel == 2) {
        // Sadece 2. seviyede extraCoins[2] aktif
        extraCoins[2].position = (Vector2){ 2500, SCREEN_HEIGHT - 190 - 30 };
        extraCoins[2].collected = false;
    }
    else {
        // 1. seviyede extraCoins[2] görünmez ve toplanamaz
        extraCoins[2].position = (Vector2){ 0, 0 };
        extraCoins[2].collected = true;
    }

    platforms[PLATFORM_COUNT].rect = (Rectangle){
       (currentLevel == 2) ? 2800 : 2200,
       (currentLevel == 2) ? -200 : 0,
       8,
       (currentLevel == 2) ? SCREEN_HEIGHT + 300 : SCREEN_HEIGHT
    };
    platforms[PLATFORM_COUNT].hasCoin = false;
    platforms[PLATFORM_COUNT].coinCollected = false;
    platforms[PLATFORM_COUNT].isFinishLine = true;

    maxCoins = 0;
    for (int i = 0; i < PLATFORM_COUNT; i++) {
        if (platforms[i].hasCoin) maxCoins++;
    }
    // Extra coins: extraCoins[0], extraCoins[1], ve 2. seviyede extraCoins[2]
    maxCoins += (currentLevel == 1) ? 2 : 3;
    // Vanishing platform coini (sadece 2. seviyede)
    if (currentLevel == 2) maxCoins++;
    // Botlar: 1. seviyede 4 bot, 2. seviyede 3 bot
    maxCoins += (currentLevel == 1) ? 4 : 3;
    // 2. seviyede 1. seviyenin coinlerini ekle
    if (currentLevel == 2) maxCoins += 14; // 1. seviyenin 14 coini
}

void GenerateRocks(void) {
    int groundLevel = SCREEN_HEIGHT - 40;

    if (currentLevel == 1) {
        rocks[0].rect = (Rectangle){ 750, groundLevel - 40, 40, 40 };
        rocks[1].rect = (Rectangle){ 1550, groundLevel - 40, 40, 40 };
    }
    else {
        rocks[0].rect = (Rectangle){ 0, 0, 0, 0 };
        rocks[1].rect = (Rectangle){ 0, 0, 0, 0 };

        pushableBox.rect = (Rectangle){ 1820, SCREEN_HEIGHT - 120, 80, 80 }; // 80x80 kare, zeminden 40 piksel yukarı itilebilir kutu konumu
        pushableBox.velocity = (Vector2){ 0, 0 };
        pushableBox.originalX = pushableBox.rect.x;
        pushableBox.rightBound = 2720.0f;
    }
}

void GenerateBots(void) {
    int groundLevel = SCREEN_HEIGHT - 40;

    if (currentLevel == 1) {
        bots[0].rect = (Rectangle){ 450, groundLevel - 32, 35, 35 };
        bots[0].alive = true;
        bots[0].direction = 1;
        bots[0].speed = 1.8f;
        bots[0].leftBound = 350;
        bots[0].rightBound = 500;
        bots[0].stuckTimer = 0.0f;
        bots[0].lastPosition = (Vector2){ bots[0].rect.x, bots[0].rect.y };
        bots[0].rotation = 0.0f; // Yeni: Rotasyon başlangıç değeri

        bots[1].rect = (Rectangle){ 900, groundLevel - 32, 35, 35 };
        bots[1].alive = true;
        bots[1].direction = -1;
        bots[1].speed = 1.8f;
        bots[1].leftBound = 800;
        bots[1].rightBound = 1000;
        bots[1].stuckTimer = 0.0f;
        bots[1].lastPosition = (Vector2){ bots[1].rect.x, bots[1].rect.y };
        bots[1].rotation = 0.0f;

        bots[2].rect = (Rectangle){ 1400, groundLevel - 32, 35, 35 };
        bots[2].alive = true;
        bots[2].direction = 1;
        bots[2].speed = 1.8f;
        bots[2].leftBound = 1300;
        bots[2].rightBound = 1500;
        bots[2].stuckTimer = 0.0f;
        bots[2].lastPosition = (Vector2){ bots[2].rect.x, bots[2].rect.y };
        bots[2].rotation = 0.0f;

        bots[3].rect = (Rectangle){ 1800, groundLevel - 32, 35, 35 };
        bots[3].alive = true;
        bots[3].direction = -1;
        bots[3].speed = 1.8f;
        bots[3].leftBound = 1700;
        bots[3].rightBound = 1900;
        bots[3].stuckTimer = 0.0f;
        bots[3].lastPosition = (Vector2){ bots[3].rect.x, bots[3].rect.y };
        bots[3].rotation = 0.0f;
    }
    else {
        bots[0].rect = (Rectangle){ 200, SCREEN_HEIGHT - 70, 35, 35 };
        bots[0].alive = true;
        bots[0].direction = 1;
        bots[0].speed = 1.8f;
        bots[0].leftBound = 150;
        bots[0].rightBound = 300;
        bots[0].stuckTimer = 0.0f;
        bots[0].lastPosition = (Vector2){ bots[0].rect.x, bots[0].rect.y };
        bots[0].rotation = 0.0f;

        bots[1].rect = (Rectangle){ 1700, SCREEN_HEIGHT - 70, 35, 35 };
        bots[1].alive = true;
        bots[1].direction = -1;
        bots[1].speed = 1.8;
        bots[1].leftBound = 100;
        bots[1].rightBound = 1800;
        bots[1].stuckTimer = 0.0f;
        bots[1].lastPosition = (Vector2){ bots[1].rect.x, bots[1].rect.y };
        bots[1].rotation = 0.0f;

        bots[2].rect = (Rectangle){ 2400, SCREEN_HEIGHT - 190 - 30, 35, 35 }; // x=2600 yerine 2400
        bots[2].alive = true;
        bots[2].direction = 1;
        bots[2].speed = 1.8f;
        bots[2].leftBound = 2400; // Hareket alanı sola kaydırıldı
        bots[2].rightBound = 2700; // Hareket alanı genişletildi (150'den 300 birime)
        bots[2].stuckTimer = 0.0f;
        bots[2].lastPosition = (Vector2){ bots[2].rect.x, bots[2].rect.y };
        bots[2].rotation = 0.0f;

        bots[3].rect = (Rectangle){ 0, 0, 0, 0 };
        bots[3].alive = false;
    }
}

bool CheckCollisionCircleRect(Vector2 center, float radius, Rectangle rect) {
    float closestX = center.x;
    float closestY = center.y;

    if (center.x < rect.x) closestX = rect.x;
    else if (center.x > rect.x + rect.width) closestX = rect.x + rect.width;

    if (center.y < rect.y) closestY = rect.y;
    else if (center.y > rect.y + rect.height) closestY = rect.y + rect.height;

    float distanceX = center.x - closestX;
    float distanceY = center.y - closestY;

    return (distanceX * distanceX + distanceY * distanceY) <= (radius * radius);
}

bool CheckPlayerInGap(Vector2 playerPos, float radius) {
    for (int i = 0; i < GAP_COUNT; i++) {
        if (gaps[i].active) {
            if (playerPos.x - radius >= gaps[i].startX && playerPos.x + radius <= gaps[i].endX &&
                playerPos.y + radius > SCREEN_HEIGHT - 40) {
                return true;
            }
        }
    }
    return false;
}

bool CheckCollisionCircleCircle(Vector2 center1, float radius1, Vector2 center2, float radius2) {
    float dx = center1.x - center2.x;
    float dy = center1.y - center2.y;
    float distance = sqrtf(dx * dx + dy * dy);
    return distance < (radius1 + radius2);
}

bool HandleRectangleCollision(Vector2* playerPos, Vector2* playerVel, Vector2 oldPos, float radius, Rectangle rect, bool* onGround, bool isPlatform) {
    bool collision = false;

    if (CheckCollisionCircleRect(*playerPos, radius, rect)) {
        // En yakın kenarı bul
        float closestX = playerPos->x;
        float closestY = playerPos->y;

        if (playerPos->x < rect.x) closestX = rect.x;
        else if (playerPos->x > rect.x + rect.width) closestX = rect.x + rect.width;

        if (playerPos->y < rect.y) closestY = rect.y;
        else if (playerPos->y > rect.y + rect.height) closestY = rect.y + rect.height;

        float distanceX = playerPos->x - closestX;
        float distanceY = playerPos->y - closestY;
        float distance = sqrtf(distanceX * distanceX + distanceY * distanceY);

        if (distance <= radius) {
            // Çarpışma yönünü belirle
            float leftDist = fabsf((oldPos.x + radius) - rect.x);
            float rightDist = fabsf((oldPos.x - radius) - (rect.x + rect.width));
            float topDist = fabsf((oldPos.y + radius) - rect.y);
            float bottomDist = fabsf((oldPos.y - radius) - (rect.y + rect.height));

            float minDist = fminf(fminf(leftDist, rightDist), fminf(topDist, bottomDist));

            if (minDist == topDist && playerVel->y >= 0 && oldPos.y + radius <= rect.y + 20) {
                // Üst kenar çarpışması: Top kutunun üzerinde durmalı
                playerPos->y = rect.y - radius;
                playerVel->y = 0;
                *onGround = true;
                collision = true;
            }
            else if (minDist == bottomDist && playerVel->y <= 0 && oldPos.y - radius >= rect.y + rect.height - 5) {
                // Alt kenar çarpışması
                playerPos->y = rect.y + rect.height + radius;
                playerVel->y = 0;
                collision = true;
            }
            else if (minDist == leftDist && playerVel->x >= 0) {
                // Sol kenar çarpışması
                playerPos->x = rect.x - radius;
                playerVel->x = 0;
                collision = true;
            }
            else if (minDist == rightDist && playerVel->x <= 0) {
                // Sağ kenar çarpışması
                playerPos->x = rect.x + rect.width + radius;
                playerVel->x = 0;
                collision = true;
            }
            else if (playerPos->y + radius > rect.y && playerPos->y - radius < rect.y + rect.height) {
                // Top kutunun içinde, yukarı it
                playerPos->y = rect.y - radius;
                playerVel->y = 0;
                *onGround = true;
                collision = true;
            }
        }
    }

    return collision;
}

int main(void) {
    InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Red Ball 4");
    SetTargetFPS(60);

    srand((unsigned int)time(NULL));


    InitializeMenuAssets();
    InitializeMenuButtons();
    LoadGameSettings();




    bool shouldClose = false; // Kapanma bayrağı

    while (!shouldClose && !WindowShouldClose()) {
        switch (currentGameState) {
        case STATE_MENU:
            HandleMenuInput(&shouldClose); // shouldClose parametre olarak geçiyor
            break;
        case STATE_SETTINGS:
            HandleSettingsInput();
            break;
        case STATE_ENTER_NAME:
            HandleEnterNameInput();
            break;
        case STATE_PLAYING:
            UpdateGame();
            HandleGameInput();
            break;
        case STATE_LEVEL_TRANSITION:
            UpdateGame();
            break;
        case STATE_GAME_OVER:
            HandleGameInput();
            break;
        case STATE_LEADERBOARD:
            HandleLeaderboardInput();
            break;
        default:
            break;
        }

        BeginDrawing();
        switch (currentGameState) {
        case STATE_MENU:
            DrawMenu();
            break;
        case STATE_SETTINGS:
            DrawSettings();
            break;
        case STATE_ENTER_NAME:
            DrawEnterName();
            break;
        case STATE_PLAYING:
        case STATE_LEVEL_TRANSITION:
        case STATE_GAME_OVER:
            DrawGame();
            break;
        case STATE_LEADERBOARD:
            DrawLeaderboard();
            break;
        default:
            break;
        }
        EndDrawing();
    }

    SaveGameSettings();
    UnloadMenuAssets();
    CloseWindow();
    UnloadTexture(backgroundTexture);
    UnloadTexture(enemyTexture);

    return 0;
}